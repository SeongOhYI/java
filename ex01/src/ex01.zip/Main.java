package ex01;

public class Main {

	public static void main(String[] args) {
		//TypeSample type=new TypeSample(); static를 사용하면 run을 사용할때
		//TypeSample thpe=new TypeSample();를 사용할 필요가 없다.
		
		//TypeSample.run();
		//TypeSample.run();
		//Operation.run();
		//Condition.run();
		//Repeat.run();
		//Dimension.run();
		//Address.run();
		  Address1.run();
		
		
		

}
}
